// main.ts
import { serve } from "https://deno.land/std@0.220.1/http/server.ts";
import { extname } from "https://deno.land/std@0.220.1/path/mod.ts";

// MIME type mapping
const MIME_TYPES: Record<string, string> = {
  ".html": "text/html",
  ".riv": "application/octet-stream",
  ".js": "text/javascript",
  ".css": "text/css",
};

// Keep track of WebSocket connections
const connectedClients = new Set<WebSocket>();

let server: Deno.Server | null = null;

// Function to check WebSocket connections and restart server if needed
const checkConnections = async () => {
  connectedClients.forEach((socket) => {
    if (socket.readyState === WebSocket.CLOSED || socket.readyState === WebSocket.CLOSING) {
      connectedClients.delete(socket);
      console.log("Removed disconnected client");
    }
  });

  // Restart server if no active connections
  if (connectedClients.size === 0 && server) {
    try {
      await server.shutdown();
      server = await serve(handler);
      console.log("Server restarted and ready for new connections");
    } catch (error) {
      console.error("Failed to restart server:", error);
    }
  }
};

// Start connection monitoring
const connectionMonitor = setInterval(checkConnections, 10000);

const handler = async (req: Request): Promise<Response> => {
  const url = new URL(req.url);
  
  // Handle WebSocket upgrade
  if (req.headers.get("upgrade") === "websocket") {
    const { socket, response } = Deno.upgradeWebSocket(req);
    
    socket.onopen = () => {
      connectedClients.add(socket);
      console.log("New client connected");
      // Add a heartbeat ping every 30 seconds
      const pingInterval = setInterval(() => {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send("ping");
        } else {
          clearInterval(pingInterval);
        }
      }, 30000);
    };
    
    socket.onmessage = (event) => { 
      // Optionally ignore "pong" replies if sent back from clients
      if (event.data === "pong") return;
      // Broadcast the message to all other clients
      connectedClients.forEach((client) => {
        if (client !== socket && client.readyState === WebSocket.OPEN) {
          client.send(event.data);
        }
      });
    };
    
    socket.onclose = () => {
      connectedClients.delete(socket);
      console.log("Client disconnected");
    };
    
    return response;
  }

  // Serve static files
  try {
    const filePath = url.pathname === '/' ? './index.html' : '.' + url.pathname;
    const content = await Deno.readFile(filePath);
    const extension = extname(filePath);
    const contentType = MIME_TYPES[extension] || "application/octet-stream";
    
    return new Response(content, {
      headers: { "Content-Type": contentType }
    });
  } catch (e) {
    return new Response("Not Found", { status: 404 });
  }
};

console.log("Server running...");
server = await serve(handler);

// Cleanup on server shutdown
addEventListener("unload", () => {
  clearInterval(connectionMonitor);
  connectedClients.forEach((socket) => socket.close());
  if (server) {
    server.shutdown();
  }
});