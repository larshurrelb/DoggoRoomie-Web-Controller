// Keep the tablet's screen on a.k.a. awake as long as the web app is running using the Wake Lock API

let wakeLock = null; 

const requestWakeLock = async () => {
    try {
        wakeLock = await navigator.wakeLock.request('screen');
        console.log('Wake Lock is active'); 

        wakeLock.addEventListener('release', () => {
            console.log('Wake Lock was released'); 
            requestWakeLock(); 
        }); 
    } catch (err) {
        console.error('Failed to acquire Wake Lock:', err); 
    }
}; 

document.addEventListener('DOMContentLoaded', () => {
    if ('wakeLock' in navigator) {
        requestWakeLock();
    } else {
        console.warn('Wake Lock API not supported'); 
    }
}); 

document.addEventListener('visibilitychange', () => {
    if (wakeLock !== null && document.visibilityState === 'visible') {
        requestWakeLock();
    }
});